var pairs =
{
"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"public":1}
,"public":{"apis":1}
,"apis":{"provided":1}
,"provided":{"zeenea":1}
}
;Search.control.loadWordPairs(pairs);
