var pairs =
{
"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"zeenea":1}
,"zeenea":{"scanners":1}
}
;Search.control.loadWordPairs(pairs);
