var pairs =
{
"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"authentication":1}
,"authentication":{"zeenea":1}
,"zeenea":{"platform":1}
}
;Search.control.loadWordPairs(pairs);
