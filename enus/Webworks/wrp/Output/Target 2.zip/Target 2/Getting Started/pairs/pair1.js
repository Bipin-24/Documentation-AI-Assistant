var pairs =
{
"documentation":{"provides":1}
,"provides":{"overview":1}
,"overview":{"product":1}
}
;Search.control.loadWordPairs(pairs);
