var pairs =
{
"know":{"zeenea":1}
,"documentation":{"describes":1}
,"describes":{"started":1}
,"started":{"zeenea":1}
,"zeenea":{"platform":1}
,"platform":{"suppported":1}
,"suppported":{"features":1}
}
;Search.control.loadWordPairs(pairs);
