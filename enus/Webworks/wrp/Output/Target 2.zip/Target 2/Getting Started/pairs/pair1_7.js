var pairs =
{
"first":{"steps":1}
,"documentation":{"describes":1}
,"describes":{"started":1}
,"started":{"zeenea":1}
,"zeenea":{"platform":1}
}
;Search.control.loadWordPairs(pairs);
