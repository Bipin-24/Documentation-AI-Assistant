var pairs =
{
"zeenea":{"explorer":1}
,"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"zeenea":1}
}
;Search.control.loadWordPairs(pairs);
