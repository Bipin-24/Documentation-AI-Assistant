var pairs =
{
"cross-application":{"features":1}
,"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"cross-application":1}
,"features":{"zeenea":1}
}
;Search.control.loadWordPairs(pairs);
