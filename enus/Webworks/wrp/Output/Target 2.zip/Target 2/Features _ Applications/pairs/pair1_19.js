var pairs =
{
"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"data":1}
,"data":{"stewardship":1}
,"stewardship":{"zeenea":1}
}
;Search.control.loadWordPairs(pairs);
