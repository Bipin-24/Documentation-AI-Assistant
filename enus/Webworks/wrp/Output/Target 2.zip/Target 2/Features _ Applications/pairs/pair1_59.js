var pairs =
{
"federated":{"catalog":1}
,"documentation":{"provides":1}
,"provides":{"information":1}
,"information":{"zeenea":1}
,"zeenea":{"federated":1}
}
;Search.control.loadWordPairs(pairs);
